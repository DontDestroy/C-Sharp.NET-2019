//***
// Action
//   - A simple notepad application
//   - Typing and saving a file
// Created
//   - CopyPaste � 20240503 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240503 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmNotepad: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuFileInsertDate;
    internal System.Windows.Forms.MenuItem mnuFileSaveAs;
    internal System.Windows.Forms.TextBox txtNote;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.SaveFileDialog dlgFileSave;
    internal System.Windows.Forms.Label lblNote;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MainMenu mnuNotepad;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmNotepad));
      this.mnuFileInsertDate = new System.Windows.Forms.MenuItem();
      this.mnuFileSaveAs = new System.Windows.Forms.MenuItem();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
      this.lblNote = new System.Windows.Forms.Label();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuNotepad = new System.Windows.Forms.MainMenu();
      this.SuspendLayout();
      // 
      // mnuFileInsertDate
      // 
      this.mnuFileInsertDate.Index = 1;
      this.mnuFileInsertDate.Text = "&Insert Date";
      this.mnuFileInsertDate.Click += new System.EventHandler(this.mnuFileInsertDate_Click);
      // 
      // mnuFileSaveAs
      // 
      this.mnuFileSaveAs.Index = 0;
      this.mnuFileSaveAs.Text = "&Save As ...";
      this.mnuFileSaveAs.Click += new System.EventHandler(this.mnuFileSaveAs_Click);
      // 
      // txtNote
      // 
      this.txtNote.Location = new System.Drawing.Point(16, 48);
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtNote.Size = new System.Drawing.Size(360, 184);
      this.txtNote.TabIndex = 3;
      this.txtNote.Text = "";
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 2;
      this.mnuFileExit.Text = "&Exit";
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      // 
      // dlgFileSave
      // 
      this.dlgFileSave.FileName = "doc1";
      // 
      // lblNote
      // 
      this.lblNote.Location = new System.Drawing.Point(16, 8);
      this.lblNote.Name = "lblNote";
      this.lblNote.Size = new System.Drawing.Size(240, 24);
      this.lblNote.TabIndex = 2;
      this.lblNote.Text = "Type your text and save.";
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileSaveAs,
                                                                            this.mnuFileInsertDate,
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // mnuNotepad
      // 
      this.mnuNotepad.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                               this.mnuFile});
      // 
      // frmNotepad
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 277);
      this.Controls.Add(this.txtNote);
      this.Controls.Add(this.lblNote);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuNotepad;
      this.Name = "frmNotepad";
      this.Text = "NotePad";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmNotepad'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmNotepad()
      //***
      // Action
      //   - Create instance of 'frmNotepad'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stopping the application
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click

    private void mnuFileInsertDate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Adding on top of the textfile a date
      //   - Put cursor in front of it
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtNote.Text = DateTime.Now.ToString("dd/MM/yyyy") + Environment.NewLine + txtNote.Text;
      txtNote.Select(0, 0);
    }
    // mnuFileInsertDate_Click(System.Object, System.EventArgs) Handles mnuFileInsertDate.Click

    private void mnuFileSaveAs_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Showing a file save dialog
      //     - Showing only the .txt files
      //     - Showing the current directory as default
      //   - If user has hit ok button
      //     - If there is a filename
      //       - File is saved with typed content
      //     - If not
      //       - Nothing happens
      //   - If not
      //     - Nothing happens
      //   - Put cursor in front of it
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgFileSave.Filter = "Text files (*.txt)|*.txt";
      dlgFileSave.InitialDirectory = Environment.CurrentDirectory;

      if (dlgFileSave.ShowDialog() == DialogResult.OK)
      {

        if (dlgFileSave.FileName == "")
        {
        }
        else
          // dlgFileSave.FileName <> ""
        {
          StreamWriter theFile = new StreamWriter(dlgFileSave.FileName);

          theFile.Write(txtNote.Text);
          theFile.Flush();
          theFile.Close();
        }
        // dlgFileSave.FileName = ""

      }
      else
        // dlgFileSave.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileSave.ShowDialog() = DialogResult.OK
    
    }
    // mnuFileSaveAs_Click(System.Object, System.EventArgs) Handles mnuFileSaveAs.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmNotepad
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmNotepad()
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmNotepad());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmNotepad

}
// CopyPaste.Learning