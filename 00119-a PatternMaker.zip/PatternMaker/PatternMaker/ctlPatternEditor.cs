//***
// Action
//   - Control pattern editor inherits from UserControl
//     - It can be placed at runtime on the form
//   - Base class for all the editors
//     - A save functionality must be implemented in the childs (using events)
//   - No abstract class is used here
//     - Abstract classes can't be used in Windows Forms Designer
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpctlPatternEditor : System.Windows.Forms.UserControl
	{

		#region Component Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlPatternEditor'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlPatternEditor()
      //***
      // Action
      //   - Create instance of 'cpctlPatternEditor'
      // Called by
      //   - cpBitmapPatternEditor(cpBitmapPattern)
      //   - cpDrawnPatternEditor(cpDrawnPattern)
      //   - User action (Starting the control)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // cpctlPatternEditor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public delegate void cpSavedEventHandler(System.Object theSender, System.EventArgs theEventArguments);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"
    
    public virtual event cpSavedEventHandler cpSaved;

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpctlPatternEditor

}
// CopyPaste.Learning