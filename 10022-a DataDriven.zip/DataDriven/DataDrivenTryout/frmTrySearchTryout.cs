//***
// Action
//   - Make a generic search form in a C# .NET desktop application
// Created
//   - CopyPaste � 20251211 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251211 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTrySearchTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtAddress;
    internal System.Windows.Forms.TextBox txtContactTitle;
    internal System.Windows.Forms.Label lblPostalCode;
    internal System.Windows.Forms.Label lblAddress;
    internal System.Windows.Forms.Label lblCity;
    internal System.Windows.Forms.TextBox txtCountry;
    internal System.Windows.Forms.TextBox txtRegion;
    internal System.Windows.Forms.TextBox txtPhone;
    internal System.Windows.Forms.Label lblCompanyName;
    internal System.Windows.Forms.Label lblContact;
    internal System.Windows.Forms.Label lblCustomerKey;
    internal System.Windows.Forms.Label lblPhone;
    internal System.Windows.Forms.Label lblRegion;
    internal System.Windows.Forms.Label lblCountry;
    internal System.Windows.Forms.TextBox txtFax;
    internal System.Windows.Forms.Label lblContactTitle;
    internal System.Windows.Forms.Label lblFax;
    internal System.Windows.Forms.TextBox txtIdCustomer;
    internal System.Windows.Forms.TextBox txtContactName;
    internal System.Windows.Forms.TextBox txtCompanyName;
    internal System.Windows.Forms.TextBox txtCity;
    internal System.Windows.Forms.TextBox txtPostalCode;
    internal System.Windows.Forms.Button cmdSearch;
    internal System.Windows.Forms.TextBox TextBox1;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTrySearchTryout));
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtContactTitle = new System.Windows.Forms.TextBox();
      this.lblPostalCode = new System.Windows.Forms.Label();
      this.lblAddress = new System.Windows.Forms.Label();
      this.lblCity = new System.Windows.Forms.Label();
      this.txtCountry = new System.Windows.Forms.TextBox();
      this.txtRegion = new System.Windows.Forms.TextBox();
      this.txtPhone = new System.Windows.Forms.TextBox();
      this.lblCompanyName = new System.Windows.Forms.Label();
      this.lblContact = new System.Windows.Forms.Label();
      this.lblCustomerKey = new System.Windows.Forms.Label();
      this.lblPhone = new System.Windows.Forms.Label();
      this.lblRegion = new System.Windows.Forms.Label();
      this.lblCountry = new System.Windows.Forms.Label();
      this.txtFax = new System.Windows.Forms.TextBox();
      this.lblContactTitle = new System.Windows.Forms.Label();
      this.lblFax = new System.Windows.Forms.Label();
      this.txtIdCustomer = new System.Windows.Forms.TextBox();
      this.txtContactName = new System.Windows.Forms.TextBox();
      this.txtCompanyName = new System.Windows.Forms.TextBox();
      this.txtCity = new System.Windows.Forms.TextBox();
      this.txtPostalCode = new System.Windows.Forms.TextBox();
      this.cmdSearch = new System.Windows.Forms.Button();
      this.TextBox1 = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // txtAddress
      // 
      this.txtAddress.BackColor = System.Drawing.SystemColors.Control;
      this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtAddress.Enabled = false;
      this.txtAddress.Location = new System.Drawing.Point(120, 112);
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(216, 20);
      this.txtAddress.TabIndex = 33;
      this.txtAddress.Text = "";
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.BackColor = System.Drawing.SystemColors.Control;
      this.txtContactTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtContactTitle.Enabled = false;
      this.txtContactTitle.Location = new System.Drawing.Point(120, 88);
      this.txtContactTitle.Name = "txtContactTitle";
      this.txtContactTitle.Size = new System.Drawing.Size(216, 20);
      this.txtContactTitle.TabIndex = 31;
      this.txtContactTitle.Text = "";
      // 
      // lblPostalCode
      // 
      this.lblPostalCode.Location = new System.Drawing.Point(16, 184);
      this.lblPostalCode.Name = "lblPostalCode";
      this.lblPostalCode.Size = new System.Drawing.Size(88, 16);
      this.lblPostalCode.TabIndex = 38;
      this.lblPostalCode.Text = "Postal Code";
      // 
      // lblAddress
      // 
      this.lblAddress.Location = new System.Drawing.Point(16, 112);
      this.lblAddress.Name = "lblAddress";
      this.lblAddress.Size = new System.Drawing.Size(88, 16);
      this.lblAddress.TabIndex = 32;
      this.lblAddress.Text = "Address";
      // 
      // lblCity
      // 
      this.lblCity.Location = new System.Drawing.Point(16, 136);
      this.lblCity.Name = "lblCity";
      this.lblCity.Size = new System.Drawing.Size(88, 16);
      this.lblCity.TabIndex = 34;
      this.lblCity.Text = "City";
      // 
      // txtCountry
      // 
      this.txtCountry.BackColor = System.Drawing.SystemColors.Control;
      this.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCountry.Enabled = false;
      this.txtCountry.Location = new System.Drawing.Point(120, 208);
      this.txtCountry.Name = "txtCountry";
      this.txtCountry.Size = new System.Drawing.Size(216, 20);
      this.txtCountry.TabIndex = 41;
      this.txtCountry.Text = "";
      // 
      // txtRegion
      // 
      this.txtRegion.BackColor = System.Drawing.SystemColors.Control;
      this.txtRegion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtRegion.Enabled = false;
      this.txtRegion.Location = new System.Drawing.Point(120, 160);
      this.txtRegion.Name = "txtRegion";
      this.txtRegion.Size = new System.Drawing.Size(216, 20);
      this.txtRegion.TabIndex = 37;
      this.txtRegion.Text = "";
      // 
      // txtPhone
      // 
      this.txtPhone.BackColor = System.Drawing.SystemColors.Control;
      this.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtPhone.Enabled = false;
      this.txtPhone.Location = new System.Drawing.Point(120, 232);
      this.txtPhone.Name = "txtPhone";
      this.txtPhone.Size = new System.Drawing.Size(216, 20);
      this.txtPhone.TabIndex = 43;
      this.txtPhone.Text = "";
      // 
      // lblCompanyName
      // 
      this.lblCompanyName.Location = new System.Drawing.Point(16, 40);
      this.lblCompanyName.Name = "lblCompanyName";
      this.lblCompanyName.Size = new System.Drawing.Size(88, 16);
      this.lblCompanyName.TabIndex = 25;
      this.lblCompanyName.Text = "Company Name";
      // 
      // lblContact
      // 
      this.lblContact.Location = new System.Drawing.Point(16, 64);
      this.lblContact.Name = "lblContact";
      this.lblContact.Size = new System.Drawing.Size(88, 16);
      this.lblContact.TabIndex = 27;
      this.lblContact.Text = "Contact";
      // 
      // lblCustomerKey
      // 
      this.lblCustomerKey.Location = new System.Drawing.Point(16, 16);
      this.lblCustomerKey.Name = "lblCustomerKey";
      this.lblCustomerKey.Size = new System.Drawing.Size(88, 16);
      this.lblCustomerKey.TabIndex = 23;
      this.lblCustomerKey.Text = "Customer ID";
      // 
      // lblPhone
      // 
      this.lblPhone.Location = new System.Drawing.Point(16, 232);
      this.lblPhone.Name = "lblPhone";
      this.lblPhone.Size = new System.Drawing.Size(88, 16);
      this.lblPhone.TabIndex = 42;
      this.lblPhone.Text = "Phone";
      // 
      // lblRegion
      // 
      this.lblRegion.Location = new System.Drawing.Point(16, 160);
      this.lblRegion.Name = "lblRegion";
      this.lblRegion.Size = new System.Drawing.Size(88, 16);
      this.lblRegion.TabIndex = 36;
      this.lblRegion.Text = "Region";
      // 
      // lblCountry
      // 
      this.lblCountry.Location = new System.Drawing.Point(16, 208);
      this.lblCountry.Name = "lblCountry";
      this.lblCountry.Size = new System.Drawing.Size(88, 16);
      this.lblCountry.TabIndex = 40;
      this.lblCountry.Text = "Country";
      // 
      // txtFax
      // 
      this.txtFax.BackColor = System.Drawing.SystemColors.Control;
      this.txtFax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtFax.Enabled = false;
      this.txtFax.Location = new System.Drawing.Point(120, 256);
      this.txtFax.Name = "txtFax";
      this.txtFax.Size = new System.Drawing.Size(216, 20);
      this.txtFax.TabIndex = 45;
      this.txtFax.Text = "";
      // 
      // lblContactTitle
      // 
      this.lblContactTitle.Location = new System.Drawing.Point(16, 88);
      this.lblContactTitle.Name = "lblContactTitle";
      this.lblContactTitle.Size = new System.Drawing.Size(88, 16);
      this.lblContactTitle.TabIndex = 30;
      this.lblContactTitle.Text = "Contact Title";
      // 
      // lblFax
      // 
      this.lblFax.Location = new System.Drawing.Point(16, 256);
      this.lblFax.Name = "lblFax";
      this.lblFax.Size = new System.Drawing.Size(88, 16);
      this.lblFax.TabIndex = 44;
      this.lblFax.Text = "Fax";
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.BackColor = System.Drawing.SystemColors.Control;
      this.txtIdCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtIdCustomer.Enabled = false;
      this.txtIdCustomer.Location = new System.Drawing.Point(120, 16);
      this.txtIdCustomer.Name = "txtIdCustomer";
      this.txtIdCustomer.Size = new System.Drawing.Size(216, 20);
      this.txtIdCustomer.TabIndex = 24;
      this.txtIdCustomer.Text = "";
      // 
      // txtContactName
      // 
      this.txtContactName.BackColor = System.Drawing.SystemColors.Control;
      this.txtContactName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtContactName.Enabled = false;
      this.txtContactName.Location = new System.Drawing.Point(120, 64);
      this.txtContactName.Name = "txtContactName";
      this.txtContactName.Size = new System.Drawing.Size(216, 20);
      this.txtContactName.TabIndex = 29;
      this.txtContactName.Text = "";
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.BackColor = System.Drawing.SystemColors.Control;
      this.txtCompanyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCompanyName.Enabled = false;
      this.txtCompanyName.Location = new System.Drawing.Point(120, 40);
      this.txtCompanyName.Name = "txtCompanyName";
      this.txtCompanyName.Size = new System.Drawing.Size(216, 20);
      this.txtCompanyName.TabIndex = 26;
      this.txtCompanyName.Text = "";
      // 
      // txtCity
      // 
      this.txtCity.BackColor = System.Drawing.SystemColors.Control;
      this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCity.Enabled = false;
      this.txtCity.Location = new System.Drawing.Point(120, 136);
      this.txtCity.Name = "txtCity";
      this.txtCity.Size = new System.Drawing.Size(216, 20);
      this.txtCity.TabIndex = 35;
      this.txtCity.Text = "";
      // 
      // txtPostalCode
      // 
      this.txtPostalCode.BackColor = System.Drawing.SystemColors.Control;
      this.txtPostalCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtPostalCode.Enabled = false;
      this.txtPostalCode.Location = new System.Drawing.Point(120, 184);
      this.txtPostalCode.Name = "txtPostalCode";
      this.txtPostalCode.Size = new System.Drawing.Size(216, 20);
      this.txtPostalCode.TabIndex = 39;
      this.txtPostalCode.Text = "";
      // 
      // cmdSearch
      // 
      this.cmdSearch.Location = new System.Drawing.Point(360, 248);
      this.cmdSearch.Name = "cmdSearch";
      this.cmdSearch.Size = new System.Drawing.Size(64, 24);
      this.cmdSearch.TabIndex = 46;
      this.cmdSearch.Text = "Search";
      this.cmdSearch.Click += new System.EventHandler(this.cmdSearch_Click);
      // 
      // TextBox1
      // 
      this.TextBox1.Location = new System.Drawing.Point(960, 248);
      this.TextBox1.Name = "TextBox1";
      this.TextBox1.Size = new System.Drawing.Size(64, 20);
      this.TextBox1.TabIndex = 28;
      this.TextBox1.Text = "";
      // 
      // frmTrySearchTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(448, 293);
      this.Controls.Add(this.txtAddress);
      this.Controls.Add(this.txtContactTitle);
      this.Controls.Add(this.lblPostalCode);
      this.Controls.Add(this.lblAddress);
      this.Controls.Add(this.lblCity);
      this.Controls.Add(this.txtCountry);
      this.Controls.Add(this.txtRegion);
      this.Controls.Add(this.txtPhone);
      this.Controls.Add(this.lblCompanyName);
      this.Controls.Add(this.lblContact);
      this.Controls.Add(this.lblCustomerKey);
      this.Controls.Add(this.lblPhone);
      this.Controls.Add(this.lblRegion);
      this.Controls.Add(this.lblCountry);
      this.Controls.Add(this.txtFax);
      this.Controls.Add(this.lblContactTitle);
      this.Controls.Add(this.lblFax);
      this.Controls.Add(this.txtIdCustomer);
      this.Controls.Add(this.txtContactName);
      this.Controls.Add(this.txtCompanyName);
      this.Controls.Add(this.txtCity);
      this.Controls.Add(this.txtPostalCode);
      this.Controls.Add(this.cmdSearch);
      this.Controls.Add(this.TextBox1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTrySearchTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Make a Generic Search Form Using a Windows Form Tryout";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTrySearchTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTrySearchTryout()
      //***
      // Action
      //   - Create instance of 'frmTrySearchTryout'
      // Called by
      //   - frmMainTryout.cmdGenericSearch_Click(System.Object, System.EventArgs) Handles cmdGenericSearch.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTrySearch()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSearch_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of 'frmSearch'
      //   - Display the name 'Customers'
      //   - Use the search record source 'tblCPCustomer'
      //   - Use the search field 'strCompany'
      //   - Use the key field 'strIdCustomer'
      //   - If you click on the ok button of the shown form
      //     - Load the found customer on the screen
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - frmSearchTryout()
      //   - frmSearchTryout.DisplayName(string) (Set)
      //   - frmSearchTryout.KeyField(string) (Set)
      //   - frmSearchTryout.SearchField(string) (Set)
      //   - frmSearchTryout.SearchRecordSource(string) (Set)
      //   - LoadIndividual(string)
      //   - string frmSearchTryout.ResultValue (Get)
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void LoadIndividual(string strKeyValue)
      //***
      // Action
      //   - Define and create a new data set
      //   - Define a data adapter
      //   - Define a data row
      //   - Try to
      //     - Create a SQL statement to filter the customer with the key value
      //     - Create the data adapter using the SQL statement and the connection
      //     - Fill the data table using the data adapter
      //     - The data row becomes the first row in the data table (there is only one)
      //     - Loop thru the controls of the screen
      //       - If the control is a textbox
      //         - Generate the fieldname using the control name
      //         - Try to
      //           - Fill the control text with the data row column text
      //       - If not
      //         - Do nothing
      //   - On error
      //     - Show the SqlException message
      // Called by
      //   - cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlConnection cpGeneralRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // LoadIndividual(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTrySearchTryout

}
// CopyPaste.Learning