﻿//***
// Action
//   - A demo of benchmarking
//     - Used BenchMarkDotNet.Attributes
//       - BenchMarkDotNET and Microsoft.VisualStudio.DiagnosticksHub.BenchmarkDotNetDiagnosers are NuGet packages
// Created
//   - CopyPaste – 20260624 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260624 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using Iced.Intel;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - A demo of benchmarking (Time and Memory)
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - BigInteger cpFactorial.Factorial01(BigInteger)
    //   - BigInteger cpFactorial.Factorial02(BigInteger)
    //   - cpFactorial
    //   - RunSomeCode()
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      BenchmarkRunner.Run<cpFactorial>();

      // RunSomeCode();
      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    public static void RunSomeCode()
    //***
    // Action
    //   - Run the actual code
    // Called by
    //   - Main()
    // Calls
    //   - BigInteger cpFactorial.Factorial01(BigInteger)
    //   - BigInteger cpFactorial.Factorial02(BigInteger)
    //   - BigInteger cpFactorial.Factorial03(BigInteger)
    //   - BigInteger cpFactorial.Factorial04(BigInteger)
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      BigInteger bintFactorial = 5;
      BigInteger bintResult;
      cpFactorial theFactorial = new cpFactorial();

      bintResult = theFactorial.Factorial01(bintFactorial);
      Console.WriteLine("Factorial of {0} = {1}", bintFactorial.ToString("#,##0"), bintResult.ToString("#,##0"));
      bintResult = theFactorial.Factorial02(bintFactorial);
      Console.WriteLine("Factorial of {0} = {1}", bintFactorial.ToString("#,##0"), bintResult.ToString("#,##0"));
      bintResult = theFactorial.Factorial03(bintFactorial);
      Console.WriteLine("Factorial of {0} = {1}", bintFactorial.ToString("#,##0"), bintResult.ToString("#,##0"));
      bintResult = theFactorial.Factorial04(bintFactorial);
      Console.WriteLine("Factorial of {0} = {1}", bintFactorial.ToString("#,##0"), bintResult.ToString("#,##0"));
    }
    // RunSomeCode()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning