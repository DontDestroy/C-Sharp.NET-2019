//***
// Action
//   - Form to select a SQL Server
//     - Load the different servers
//     - Load the databases from the selected server
//     - Select a backup device
//   - The goal is to backup and verify the selections 
// Created
//   - CopyPaste � 20260717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260717 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBackup : System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtVerifyDisplay;
    internal System.Windows.Forms.Button cmdVerify;
    internal System.Windows.Forms.Button cmdClose;
    internal System.Windows.Forms.Label lblOptions;
    internal System.Windows.Forms.Label lblDatabase;
    internal System.Windows.Forms.Label lblSQLServer;
    internal System.Windows.Forms.ListBox lstSQLServer;
    internal System.Windows.Forms.Label lblBackupSetName;
    internal System.Windows.Forms.Label lblBackupDevice;
    internal System.Windows.Forms.Button cmdBackup;
    internal System.Windows.Forms.ListBox lstDatabase;
    internal System.Windows.Forms.ListBox lstBackupDevice;
    internal System.Windows.Forms.Panel panOptions;
    internal System.Windows.Forms.CheckBox chkInitialize;
    internal System.Windows.Forms.GroupBox grpTruncateLog;
    internal System.Windows.Forms.RadioButton optTruncate;
    internal System.Windows.Forms.RadioButton optNoTruncate;
    internal System.Windows.Forms.RadioButton optNoLog;
    internal System.Windows.Forms.TextBox txtBackupSetDescription;
    internal System.Windows.Forms.Label lblBackupSetDescription;
    internal System.Windows.Forms.GroupBox grpAction;
    internal System.Windows.Forms.RadioButton optIncremental;
    internal System.Windows.Forms.RadioButton optFull;
    internal System.Windows.Forms.TextBox txtBackupSetName;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBackup));
      this.txtVerifyDisplay = new System.Windows.Forms.TextBox();
      this.cmdVerify = new System.Windows.Forms.Button();
      this.cmdClose = new System.Windows.Forms.Button();
      this.lblOptions = new System.Windows.Forms.Label();
      this.lblDatabase = new System.Windows.Forms.Label();
      this.lblSQLServer = new System.Windows.Forms.Label();
      this.lstSQLServer = new System.Windows.Forms.ListBox();
      this.lblBackupSetName = new System.Windows.Forms.Label();
      this.lblBackupDevice = new System.Windows.Forms.Label();
      this.cmdBackup = new System.Windows.Forms.Button();
      this.lstDatabase = new System.Windows.Forms.ListBox();
      this.lstBackupDevice = new System.Windows.Forms.ListBox();
      this.panOptions = new System.Windows.Forms.Panel();
      this.chkInitialize = new System.Windows.Forms.CheckBox();
      this.grpTruncateLog = new System.Windows.Forms.GroupBox();
      this.optTruncate = new System.Windows.Forms.RadioButton();
      this.optNoTruncate = new System.Windows.Forms.RadioButton();
      this.optNoLog = new System.Windows.Forms.RadioButton();
      this.txtBackupSetDescription = new System.Windows.Forms.TextBox();
      this.lblBackupSetDescription = new System.Windows.Forms.Label();
      this.grpAction = new System.Windows.Forms.GroupBox();
      this.optIncremental = new System.Windows.Forms.RadioButton();
      this.optFull = new System.Windows.Forms.RadioButton();
      this.txtBackupSetName = new System.Windows.Forms.TextBox();
      this.panOptions.SuspendLayout();
      this.grpTruncateLog.SuspendLayout();
      this.grpAction.SuspendLayout();
      this.SuspendLayout();
      // 
      // txtVerifyDisplay
      // 
      this.txtVerifyDisplay.BackColor = System.Drawing.SystemColors.Control;
      this.txtVerifyDisplay.Location = new System.Drawing.Point(8, 352);
      this.txtVerifyDisplay.Multiline = true;
      this.txtVerifyDisplay.Name = "txtVerifyDisplay";
      this.txtVerifyDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtVerifyDisplay.Size = new System.Drawing.Size(352, 80);
      this.txtVerifyDisplay.TabIndex = 25;
      // 
      // cmdVerify
      // 
      this.cmdVerify.Location = new System.Drawing.Point(368, 352);
      this.cmdVerify.Name = "cmdVerify";
      this.cmdVerify.Size = new System.Drawing.Size(80, 32);
      this.cmdVerify.TabIndex = 26;
      this.cmdVerify.Text = "&Verify";
      this.cmdVerify.Click += new System.EventHandler(this.cmdVerify_Click);
      // 
      // cmdClose
      // 
      this.cmdClose.Location = new System.Drawing.Point(368, 400);
      this.cmdClose.Name = "cmdClose";
      this.cmdClose.Size = new System.Drawing.Size(80, 32);
      this.cmdClose.TabIndex = 27;
      this.cmdClose.Text = "&Close";
      this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
      // 
      // lblOptions
      // 
      this.lblOptions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblOptions.Location = new System.Drawing.Point(8, 168);
      this.lblOptions.Name = "lblOptions";
      this.lblOptions.Size = new System.Drawing.Size(48, 16);
      this.lblOptions.TabIndex = 23;
      this.lblOptions.Text = "Options";
      // 
      // lblDatabase
      // 
      this.lblDatabase.Location = new System.Drawing.Point(128, 24);
      this.lblDatabase.Name = "lblDatabase";
      this.lblDatabase.Size = new System.Drawing.Size(120, 16);
      this.lblDatabase.TabIndex = 16;
      this.lblDatabase.Text = "Database to Backup";
      // 
      // lblSQLServer
      // 
      this.lblSQLServer.Location = new System.Drawing.Point(8, 24);
      this.lblSQLServer.Name = "lblSQLServer";
      this.lblSQLServer.Size = new System.Drawing.Size(104, 16);
      this.lblSQLServer.TabIndex = 14;
      this.lblSQLServer.Text = "SQL Servers";
      // 
      // lstSQLServer
      // 
      this.lstSQLServer.Location = new System.Drawing.Point(8, 40);
      this.lstSQLServer.Name = "lstSQLServer";
      this.lstSQLServer.Size = new System.Drawing.Size(104, 82);
      this.lstSQLServer.TabIndex = 15;
      this.lstSQLServer.SelectedIndexChanged += new System.EventHandler(this.lstSQLServer_SelectedIndexChanged);
      // 
      // lblBackupSetName
      // 
      this.lblBackupSetName.Location = new System.Drawing.Point(8, 136);
      this.lblBackupSetName.Name = "lblBackupSetName";
      this.lblBackupSetName.Size = new System.Drawing.Size(112, 16);
      this.lblBackupSetName.TabIndex = 21;
      this.lblBackupSetName.Text = "Backup Set Name:";
      // 
      // lblBackupDevice
      // 
      this.lblBackupDevice.Location = new System.Drawing.Point(248, 24);
      this.lblBackupDevice.Name = "lblBackupDevice";
      this.lblBackupDevice.Size = new System.Drawing.Size(120, 16);
      this.lblBackupDevice.TabIndex = 18;
      this.lblBackupDevice.Text = "Backup Devices";
      // 
      // cmdBackup
      // 
      this.cmdBackup.Location = new System.Drawing.Point(368, 40);
      this.cmdBackup.Name = "cmdBackup";
      this.cmdBackup.Size = new System.Drawing.Size(80, 32);
      this.cmdBackup.TabIndex = 20;
      this.cmdBackup.Text = "&Backup";
      this.cmdBackup.Click += new System.EventHandler(this.cmdBackup_Click);
      // 
      // lstDatabase
      // 
      this.lstDatabase.Location = new System.Drawing.Point(128, 40);
      this.lstDatabase.Name = "lstDatabase";
      this.lstDatabase.Size = new System.Drawing.Size(104, 82);
      this.lstDatabase.TabIndex = 17;
      // 
      // lstBackupDevice
      // 
      this.lstBackupDevice.Location = new System.Drawing.Point(248, 40);
      this.lstBackupDevice.Name = "lstBackupDevice";
      this.lstBackupDevice.Size = new System.Drawing.Size(112, 82);
      this.lstBackupDevice.TabIndex = 19;
      // 
      // panOptions
      // 
      this.panOptions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panOptions.Controls.Add(this.chkInitialize);
      this.panOptions.Controls.Add(this.grpTruncateLog);
      this.panOptions.Controls.Add(this.txtBackupSetDescription);
      this.panOptions.Controls.Add(this.lblBackupSetDescription);
      this.panOptions.Controls.Add(this.grpAction);
      this.panOptions.Location = new System.Drawing.Point(8, 184);
      this.panOptions.Name = "panOptions";
      this.panOptions.Size = new System.Drawing.Size(440, 160);
      this.panOptions.TabIndex = 24;
      // 
      // chkInitialize
      // 
      this.chkInitialize.Checked = true;
      this.chkInitialize.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chkInitialize.Location = new System.Drawing.Point(368, 72);
      this.chkInitialize.Name = "chkInitialize";
      this.chkInitialize.Size = new System.Drawing.Size(64, 24);
      this.chkInitialize.TabIndex = 4;
      this.chkInitialize.Text = "Initialize";
      // 
      // grpTruncateLog
      // 
      this.grpTruncateLog.Controls.Add(this.optTruncate);
      this.grpTruncateLog.Controls.Add(this.optNoTruncate);
      this.grpTruncateLog.Controls.Add(this.optNoLog);
      this.grpTruncateLog.Location = new System.Drawing.Point(176, 16);
      this.grpTruncateLog.Name = "grpTruncateLog";
      this.grpTruncateLog.Size = new System.Drawing.Size(256, 48);
      this.grpTruncateLog.TabIndex = 1;
      this.grpTruncateLog.TabStop = false;
      this.grpTruncateLog.Text = "Truncate Log";
      // 
      // optTruncate
      // 
      this.optTruncate.Location = new System.Drawing.Point(176, 16);
      this.optTruncate.Name = "optTruncate";
      this.optTruncate.Size = new System.Drawing.Size(72, 24);
      this.optTruncate.TabIndex = 2;
      this.optTruncate.Text = "Truncate";
      // 
      // optNoTruncate
      // 
      this.optNoTruncate.Checked = true;
      this.optNoTruncate.Location = new System.Drawing.Point(80, 16);
      this.optNoTruncate.Name = "optNoTruncate";
      this.optNoTruncate.Size = new System.Drawing.Size(88, 24);
      this.optNoTruncate.TabIndex = 1;
      this.optNoTruncate.TabStop = true;
      this.optNoTruncate.Text = "No Truncate";
      // 
      // optNoLog
      // 
      this.optNoLog.Location = new System.Drawing.Point(8, 16);
      this.optNoLog.Name = "optNoLog";
      this.optNoLog.Size = new System.Drawing.Size(64, 24);
      this.optNoLog.TabIndex = 0;
      this.optNoLog.Text = "No Log";
      // 
      // txtBackupSetDescription
      // 
      this.txtBackupSetDescription.Location = new System.Drawing.Point(8, 96);
      this.txtBackupSetDescription.Multiline = true;
      this.txtBackupSetDescription.Name = "txtBackupSetDescription";
      this.txtBackupSetDescription.Size = new System.Drawing.Size(424, 56);
      this.txtBackupSetDescription.TabIndex = 3;
      this.txtBackupSetDescription.Text = "MyTestBackup";
      // 
      // lblBackupSetDescription
      // 
      this.lblBackupSetDescription.Location = new System.Drawing.Point(8, 80);
      this.lblBackupSetDescription.Name = "lblBackupSetDescription";
      this.lblBackupSetDescription.Size = new System.Drawing.Size(128, 16);
      this.lblBackupSetDescription.TabIndex = 2;
      this.lblBackupSetDescription.Text = "Backup Set Description";
      // 
      // grpAction
      // 
      this.grpAction.Controls.Add(this.optIncremental);
      this.grpAction.Controls.Add(this.optFull);
      this.grpAction.Location = new System.Drawing.Point(8, 16);
      this.grpAction.Name = "grpAction";
      this.grpAction.Size = new System.Drawing.Size(152, 48);
      this.grpAction.TabIndex = 0;
      this.grpAction.TabStop = false;
      this.grpAction.Text = "Action";
      // 
      // optIncremental
      // 
      this.optIncremental.Location = new System.Drawing.Point(56, 16);
      this.optIncremental.Name = "optIncremental";
      this.optIncremental.Size = new System.Drawing.Size(88, 24);
      this.optIncremental.TabIndex = 1;
      this.optIncremental.Text = "Incremental";
      // 
      // optFull
      // 
      this.optFull.Checked = true;
      this.optFull.Location = new System.Drawing.Point(8, 16);
      this.optFull.Name = "optFull";
      this.optFull.Size = new System.Drawing.Size(48, 24);
      this.optFull.TabIndex = 0;
      this.optFull.TabStop = true;
      this.optFull.Text = "Full";
      // 
      // txtBackupSetName
      // 
      this.txtBackupSetName.Location = new System.Drawing.Point(128, 136);
      this.txtBackupSetName.Name = "txtBackupSetName";
      this.txtBackupSetName.Size = new System.Drawing.Size(232, 20);
      this.txtBackupSetName.TabIndex = 22;
      this.txtBackupSetName.Text = "MyTestBackup";
      // 
      // frmBackup
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 445);
      this.Controls.Add(this.txtVerifyDisplay);
      this.Controls.Add(this.cmdVerify);
      this.Controls.Add(this.cmdClose);
      this.Controls.Add(this.lblOptions);
      this.Controls.Add(this.lblDatabase);
      this.Controls.Add(this.lblSQLServer);
      this.Controls.Add(this.lstSQLServer);
      this.Controls.Add(this.lblBackupSetName);
      this.Controls.Add(this.lblBackupDevice);
      this.Controls.Add(this.cmdBackup);
      this.Controls.Add(this.lstDatabase);
      this.Controls.Add(this.lstBackupDevice);
      this.Controls.Add(this.panOptions);
      this.Controls.Add(this.txtBackupSetName);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBackup";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Backing Up and Verifying a SQL Server Database";
      this.Load += new System.EventHandler(this.frmBackup_Load);
      this.panOptions.ResumeLayout(false);
      this.panOptions.PerformLayout();
      this.grpTruncateLog.ResumeLayout(false);
      this.grpAction.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmBackup'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBackup()
    //***
    // Action
    //   - Create instance of 'frmBackup'
    // Called by
    //   - frmMain.cmdBackup_Click(System.Object, System.EventArgs) Handles cmdBackup.Click
    //   - User action (Starting the form)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmBackup()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdBackup_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize a backup
    //   - Define and initialize a SQLServer
    //   - Try to
    //     - Connect to the SQL Server with Windows Security
    //     - If optFull is checked
    //       - Make a full backup of the database
    //     - If not
    //       - Make a differential backup of the database
    //     - Set the description
    //     - Set the name
    //     - Set the database
    //     - Set the device
    //     - Depending on the option
    //       - optNoLog
    //         - Set TruncateLog to No log
    //       - optNoTrunctate
    //         - Set TruncateLog to No truncate
    //       - else
    //         - Set TruncateLog to Truncate
    //     - Initialize (or not)
    //     - Make backup
    //     - Disconnect from the server
    //     - Show messagebox that backup is successful
    //   - On possible error
    //     - Show messageboxes with corresponding info 
    //   - Set the server to nothing
    //   - Set the backup to nothing
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Backup theBackup = new Backup();
      Server theSQLServer;

      try
      {
        theSQLServer = new Server(lstSQLServer.SelectedItem.ToString());
        theSQLServer.ConnectionContext.Connect();

        if (optFull.Checked)
        {
          theBackup.Action = BackupActionType.Database;
          theBackup.Incremental = false;
        }
        else
        // Not optFull.Checked
        {
          theBackup.Action = BackupActionType.Database;
          theBackup.Incremental = true;
        }
        // optFull.Checked

        theBackup.BackupSetDescription = txtBackupSetDescription.Text;
        theBackup.BackupSetName = txtBackupSetName.Text;
        theBackup.Database = lstDatabase.SelectedItem.ToString();
        theBackup.Devices.AddDevice(lstBackupDevice.SelectedItem.ToString() + ".bak", DeviceType.File);

        if (optNoLog.Checked)
        {
          theBackup.LogTruncation = BackupTruncateLogType.TruncateOnly;
        }
        else if (optNoTruncate.Checked)
        // optNoLog.Checked
        {
          theBackup.LogTruncation = BackupTruncateLogType.NoTruncate;
        }
        else
        // optNoTruncate.Checked
        {
          theBackup.LogTruncation = BackupTruncateLogType.Truncate;
        }
        // optNoLog.Checked

        theBackup.Initialize = chkInitialize.Checked;
        theBackup.SqlBackup(theSQLServer);
        theSQLServer.ConnectionContext.Disconnect();
        MessageBox.Show("Database Backed Up", "Task Completed", MessageBoxButtons.OK);
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        MessageBox.Show("There is a problem retrieving databases for this server. " +
          "Please check the name and try again. ", "Error with Server", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
      finally
      {
        theSQLServer = null;
        theBackup = null;
      }

    }
    // cmdBackup_Click(System.Object, System.EventArgs) Handles cmdBackup.Click

    private void cmdClose_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Close the form
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      this.Close();
    }
    // cmdClose_Click(System.Object, System.EventArgs) Handles cmdClose.Click

    private void cmdVerify_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a column and a row
    //   - Define a backup device
    //   - Define a query result
    //   - Define and initialize a SQLServer
    //   - Try to
    //     - Connect to the SQL Server with Windows Security
    //     - Loop thru the backup devices
    //       - If the device name is the one that is selected
    //         - Read backup header into query results
    //         - Loop thru the query results (rows)
    //           - Loop thru the fields (columns)
    //             - Update verify display with the information of the query results
    //   - On possible error
    //     - Show messageboxes with corresponding info 
    //   - Set the server to nothing
    //   - Set the backup device to nothing
    //   - Set the query result to nothing
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      DataTable theQueryResults;
      int lngColumn;
      int lngRow;
      Server theSQLServer;

      try
      {
        theSQLServer = new Server(lstSQLServer.SelectedItem.ToString());
        theSQLServer.ConnectionContext.Connect();

        foreach (BackupDevice theBackupDevice in theSQLServer.BackupDevices)
        {
          if (theBackupDevice.Name == lstBackupDevice.SelectedItem.ToString())
          {
            theQueryResults = theBackupDevice.ReadBackupHeader();

            for (lngRow = 0; lngRow < theQueryResults.Rows.Count; lngRow++)
            {

              for (lngColumn = 0; lngColumn < theQueryResults.Columns.Count; lngColumn++)
              {
                txtVerifyDisplay.Text += theQueryResults.Columns[lngColumn].ColumnName + " - ";
                txtVerifyDisplay.Text += theQueryResults.Rows[lngRow].ItemArray[lngColumn].ToString() + Environment.NewLine;
              }
              // lngColumn = theQueryResults.Columns.Count

            }
            // lngRow = theQueryResults.Rows.Count

          }
          else
          // theBackupDevice.Name <> lstBackupDevice.SelectedItem.ToString()
          {
          }
          // theBackupDevice.Name = lstBackupDevice.SelectedItem.ToString() 

        }
        // in theSQLServer.BackupDevices

        theSQLServer.ConnectionContext.Disconnect();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        MessageBox.Show("There is a problem retrieving databases for this server. " +
          "Please check the name and try again. ", "Error with Server", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
      finally
      {
        theSQLServer = null;
        theQueryResults = null;
      }

    }
    // cmdVerify_Click(System.Object, System.EventArgs) Handles cmdVerify.Click

    private void frmBackup_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Load the list of SQL Servers
    // Called by
    //   - User action (Starting a form)
    // Calls
    //   - cpSQLDMORoutines.LoadSQLServer(�ListBox)
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cpSQLDMORoutines.LoadSQLServer(ref lstSQLServer);
    }
    // frmBackup_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstSQLServer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Get SQL databases
    //   - Get the backup devices
    // Called by
    //   - User action (Choosing an option)
    // Calls
    //   - cpSQLDMORoutines.GetSQLDatabase(String, �ListBox)
    //   - cpSQLDMORoutines.GetBackupDevice(String, �ListBox)
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cpSQLDMORoutines.GetSQLDatabase(lstSQLServer.SelectedItem.ToString(), ref lstDatabase);
      cpSQLDMORoutines.GetBackupDevice(lstSQLServer.SelectedItem.ToString(), ref lstBackupDevice);
    }
    // lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBackup

}
// CopyPaste.Learning